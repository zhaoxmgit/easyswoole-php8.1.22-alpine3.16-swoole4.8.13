<?php
//全局bootstrap事件
date_default_timezone_set('Asia/Shanghai');